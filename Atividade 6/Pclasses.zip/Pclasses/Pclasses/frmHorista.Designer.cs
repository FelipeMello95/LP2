﻿namespace Pclasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClear = new System.Windows.Forms.Button();
            this.btnInstaciarHora = new System.Windows.Forms.Button();
            this.lblData = new System.Windows.Forms.Label();
            this.lnlNumero = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtNumero = new System.Windows.Forms.TextBox();
            this.txtnNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.lblSalHora = new System.Windows.Forms.Label();
            this.lblDiasFaalta = new System.Windows.Forms.Label();
            this.txtDiasFalta = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(559, 427);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(155, 47);
            this.btnClear.TabIndex = 7;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnInstaciarHora
            // 
            this.btnInstaciarHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstaciarHora.Location = new System.Drawing.Point(78, 393);
            this.btnInstaciarHora.Name = "btnInstaciarHora";
            this.btnInstaciarHora.Size = new System.Drawing.Size(372, 115);
            this.btnInstaciarHora.TabIndex = 6;
            this.btnInstaciarHora.Text = "Instanciar Horista";
            this.btnInstaciarHora.UseVisualStyleBackColor = true;
            this.btnInstaciarHora.Click += new System.EventHandler(this.btnInstaciarHora_Click);
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(192, 279);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(259, 25);
            this.lblData.TabIndex = 19;
            this.lblData.Text = "Data Entrada na Empresa";
            // 
            // lnlNumero
            // 
            this.lnlNumero.AutoSize = true;
            this.lnlNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnlNumero.Location = new System.Drawing.Point(192, 220);
            this.lnlNumero.Name = "lnlNumero";
            this.lnlNumero.Size = new System.Drawing.Size(180, 25);
            this.lnlNumero.TabIndex = 18;
            this.lnlNumero.Text = "Número de Horas";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(192, 102);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(68, 25);
            this.lblNome.TabIndex = 17;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(192, 42);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(100, 25);
            this.lblMatricula.TabIndex = 16;
            this.lblMatricula.Text = "Matricula";
            // 
            // txtData
            // 
            this.txtData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData.Location = new System.Drawing.Point(490, 274);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(262, 30);
            this.txtData.TabIndex = 4;
            // 
            // txtNumero
            // 
            this.txtNumero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumero.Location = new System.Drawing.Point(490, 215);
            this.txtNumero.Name = "txtNumero";
            this.txtNumero.Size = new System.Drawing.Size(262, 30);
            this.txtNumero.TabIndex = 3;
            // 
            // txtnNome
            // 
            this.txtnNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnNome.Location = new System.Drawing.Point(490, 102);
            this.txtnNome.Name = "txtnNome";
            this.txtnNome.Size = new System.Drawing.Size(262, 30);
            this.txtnNome.TabIndex = 1;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(490, 39);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(262, 30);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalarioHora.Location = new System.Drawing.Point(490, 156);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(262, 30);
            this.txtSalarioHora.TabIndex = 2;
            // 
            // lblSalHora
            // 
            this.lblSalHora.AutoSize = true;
            this.lblSalHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalHora.Location = new System.Drawing.Point(192, 156);
            this.lblSalHora.Name = "lblSalHora";
            this.lblSalHora.Size = new System.Drawing.Size(169, 25);
            this.lblSalHora.TabIndex = 24;
            this.lblSalHora.Text = "Salário por Hora";
            // 
            // lblDiasFaalta
            // 
            this.lblDiasFaalta.AutoSize = true;
            this.lblDiasFaalta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiasFaalta.Location = new System.Drawing.Point(192, 335);
            this.lblDiasFaalta.Name = "lblDiasFaalta";
            this.lblDiasFaalta.Size = new System.Drawing.Size(139, 25);
            this.lblDiasFaalta.TabIndex = 26;
            this.lblDiasFaalta.Text = "Dias de Falta";
            // 
            // txtDiasFalta
            // 
            this.txtDiasFalta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiasFalta.Location = new System.Drawing.Point(490, 330);
            this.txtDiasFalta.Name = "txtDiasFalta";
            this.txtDiasFalta.Size = new System.Drawing.Size(262, 30);
            this.txtDiasFalta.TabIndex = 5;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 583);
            this.Controls.Add(this.lblDiasFaalta);
            this.Controls.Add(this.txtDiasFalta);
            this.Controls.Add(this.lblSalHora);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnInstaciarHora);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lnlNumero);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtNumero);
            this.Controls.Add(this.txtnNome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnInstaciarHora;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lnlNumero;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtNumero;
        private System.Windows.Forms.TextBox txtnNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.Label lblSalHora;
        private System.Windows.Forms.Label lblDiasFaalta;
        private System.Windows.Forms.TextBox txtDiasFalta;
    }
}