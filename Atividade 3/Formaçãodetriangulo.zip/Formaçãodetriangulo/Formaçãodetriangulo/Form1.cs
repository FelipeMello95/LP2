﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Formaçãodetriangulo{
    public partial class Form1 : Form
    {
        double LadoA, LadoB, LadoC;
        string Classificacao;

        private void txtladoB_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtladoB.Text, out LadoB) || LadoB == 0)
            {
                MessageBox.Show("Valor inválido!");
                txtladoB.Focus();
            }
        }

        private void txtladoC_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtladoC.Text, out LadoC) || LadoC == 0)
            {
                MessageBox.Show("Valor inválido!");
                txtladoC.Focus();
            }
        }

        private void Class_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(LadoB-LadoC) < LadoA && LadoA < LadoB + LadoC) && (Math.Abs(LadoA-LadoC) < LadoB && LadoB < LadoA + LadoC) && (Math.Abs(LadoA-LadoB) < LadoC && LadoC < LadoA + LadoB))
            {
                if (LadoA == LadoB && LadoB == LadoC)
                    Classificacao = "equilátero!";
                else
                    if (LadoA != LadoB && LadoB != LadoC && LadoA != LadoC)
                    Classificacao = "escaleno!";
                else
                    Classificacao = "isósceles!";
                txtclassifica.Text = ("É um triângulo " + Classificacao);
            }
            else
            {
                txtclassifica.Text = ("Não é um triângulo!");
            }
        }

        private void limpar_Click(object sender, EventArgs e)
        {
            txtladoA.Clear();
            txtladoB.Clear();
            txtladoC.Clear();
            txtclassifica.Clear();
        }

        private void fechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtladoA_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtladoA.Text, out LadoA) || LadoA == 0)
            {
                MessageBox.Show("Valor inválido!");
                txtladoA.Focus();
            }
        }

        


        public Form1()
        {
            InitializeComponent();
        }
    }
}

