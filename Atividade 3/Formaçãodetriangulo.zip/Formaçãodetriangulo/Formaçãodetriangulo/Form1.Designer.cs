﻿namespace Formaçãodetriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtladoA = new System.Windows.Forms.TextBox();
            this.txtladoB = new System.Windows.Forms.TextBox();
            this.txtladoC = new System.Windows.Forms.TextBox();
            this.lado1 = new System.Windows.Forms.Label();
            this.lado2 = new System.Windows.Forms.Label();
            this.lado3 = new System.Windows.Forms.Label();
            this.Class = new System.Windows.Forms.Button();
            this.limpar = new System.Windows.Forms.Button();
            this.fechar = new System.Windows.Forms.Button();
            this.classifica = new System.Windows.Forms.Label();
            this.txtclassifica = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtladoA
            // 
            this.txtladoA.AcceptsTab = true;
            this.txtladoA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtladoA.Location = new System.Drawing.Point(180, 48);
            this.txtladoA.Margin = new System.Windows.Forms.Padding(2);
            this.txtladoA.Name = "txtladoA";
            this.txtladoA.Size = new System.Drawing.Size(160, 26);
            this.txtladoA.TabIndex = 0;
            this.txtladoA.Validated += new System.EventHandler(this.txtladoA_Validated);
            // 
            // txtladoB
            // 
            this.txtladoB.AcceptsTab = true;
            this.txtladoB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtladoB.Location = new System.Drawing.Point(180, 87);
            this.txtladoB.Margin = new System.Windows.Forms.Padding(2);
            this.txtladoB.Name = "txtladoB";
            this.txtladoB.Size = new System.Drawing.Size(160, 26);
            this.txtladoB.TabIndex = 1;
            this.txtladoB.Validated += new System.EventHandler(this.txtladoB_Validated);
            // 
            // txtladoC
            // 
            this.txtladoC.AcceptsTab = true;
            this.txtladoC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtladoC.Location = new System.Drawing.Point(180, 131);
            this.txtladoC.Margin = new System.Windows.Forms.Padding(2);
            this.txtladoC.Name = "txtladoC";
            this.txtladoC.Size = new System.Drawing.Size(160, 26);
            this.txtladoC.TabIndex = 2;
            this.txtladoC.Validated += new System.EventHandler(this.txtladoC_Validated);
            // 
            // lado1
            // 
            this.lado1.AutoSize = true;
            this.lado1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lado1.Location = new System.Drawing.Point(48, 51);
            this.lado1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lado1.Name = "lado1";
            this.lado1.Size = new System.Drawing.Size(66, 20);
            this.lado1.TabIndex = 3;
            this.lado1.Text = "Lado A";
            // 
            // lado2
            // 
            this.lado2.AutoSize = true;
            this.lado2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lado2.Location = new System.Drawing.Point(48, 90);
            this.lado2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lado2.Name = "lado2";
            this.lado2.Size = new System.Drawing.Size(66, 20);
            this.lado2.TabIndex = 4;
            this.lado2.Text = "Lado B";
            // 
            // lado3
            // 
            this.lado3.AutoSize = true;
            this.lado3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lado3.Location = new System.Drawing.Point(48, 134);
            this.lado3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lado3.Name = "lado3";
            this.lado3.Size = new System.Drawing.Size(66, 20);
            this.lado3.TabIndex = 5;
            this.lado3.Text = "Lado C";
            // 
            // Class
            // 
            this.Class.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Class.Location = new System.Drawing.Point(52, 236);
            this.Class.Margin = new System.Windows.Forms.Padding(2);
            this.Class.Name = "Class";
            this.Class.Size = new System.Drawing.Size(116, 41);
            this.Class.TabIndex = 6;
            this.Class.Text = "Classificar";
            this.Class.UseVisualStyleBackColor = true;
            this.Class.Click += new System.EventHandler(this.Class_Click);
            // 
            // limpar
            // 
            this.limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.limpar.Location = new System.Drawing.Point(180, 236);
            this.limpar.Margin = new System.Windows.Forms.Padding(2);
            this.limpar.Name = "limpar";
            this.limpar.Size = new System.Drawing.Size(116, 41);
            this.limpar.TabIndex = 7;
            this.limpar.Text = "Limpar";
            this.limpar.UseVisualStyleBackColor = true;
            this.limpar.Click += new System.EventHandler(this.limpar_Click);
            // 
            // fechar
            // 
            this.fechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fechar.Location = new System.Drawing.Point(52, 293);
            this.fechar.Margin = new System.Windows.Forms.Padding(2);
            this.fechar.Name = "fechar";
            this.fechar.Size = new System.Drawing.Size(116, 41);
            this.fechar.TabIndex = 8;
            this.fechar.Text = "Fechar";
            this.fechar.UseVisualStyleBackColor = true;
            this.fechar.Click += new System.EventHandler(this.fechar_Click);
            // 
            // classifica
            // 
            this.classifica.AutoSize = true;
            this.classifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classifica.Location = new System.Drawing.Point(48, 184);
            this.classifica.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.classifica.Name = "classifica";
            this.classifica.Size = new System.Drawing.Size(115, 20);
            this.classifica.TabIndex = 9;
            this.classifica.Text = "Classificação";
            // 
            // txtclassifica
            // 
            this.txtclassifica.AcceptsTab = true;
            this.txtclassifica.Enabled = false;
            this.txtclassifica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtclassifica.Location = new System.Drawing.Point(180, 183);
            this.txtclassifica.Name = "txtclassifica";
            this.txtclassifica.Size = new System.Drawing.Size(282, 26);
            this.txtclassifica.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(48, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(266, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Classificação de Triângulos";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(668, 350);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtclassifica);
            this.Controls.Add(this.classifica);
            this.Controls.Add(this.fechar);
            this.Controls.Add(this.limpar);
            this.Controls.Add(this.Class);
            this.Controls.Add(this.lado3);
            this.Controls.Add(this.lado2);
            this.Controls.Add(this.lado1);
            this.Controls.Add(this.txtladoC);
            this.Controls.Add(this.txtladoB);
            this.Controls.Add(this.txtladoA);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtladoA;
        private System.Windows.Forms.TextBox txtladoB;
        private System.Windows.Forms.TextBox txtladoC;
        private System.Windows.Forms.Label lado1;
        private System.Windows.Forms.Label lado2;
        private System.Windows.Forms.Label lado3;
        private System.Windows.Forms.Button Class;
        private System.Windows.Forms.Button limpar;
        private System.Windows.Forms.Button fechar;
        private System.Windows.Forms.Label classifica;
        private System.Windows.Forms.TextBox txtclassifica;
        private System.Windows.Forms.Label label1;
    }
}

